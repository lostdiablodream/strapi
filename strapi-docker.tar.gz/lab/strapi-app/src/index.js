'use strict';

const fs = require('node:fs');
const path = require('node:path');

const paragraph = (text) => [
  {
    type: 'paragraph',
    children: [{ type: 'text', text }],
  },
];

const categories = [
  {
    name: 'Микрофоны и запись',
    slug: 'microphones-and-recording',
    description: 'Выбор и использование студийных микрофонов.',
  },
  {
    name: 'Обработка звука',
    slug: 'sound-processing',
    description: 'Компрессоры, эквалайзеры и построение трактов обработки.',
  },
  {
    name: 'Студийный мониторинг',
    slug: 'studio-monitoring',
    description: 'Мониторы, акустика помещения и контроль записи.',
  },
];

const articles = [
  {
    title: 'Как выбрать ламповый микрофон',
    content: 'Разбираем капсюль, схему усиления, характер направленности и совместимость с предусилителем.',
    rating: 9.2,
    published_on: '2026-11-10',
    type: 'tutorial',
    category: 'microphones-and-recording',
    cover: true,
  },
  {
    title: 'Обзор лампового микрофона LM-1',
    content: 'LM-1 даёт плотную середину и мягкие верхние частоты. Проверяем его на вокале и акустической гитаре.',
    rating: 8.8,
    published_on: '2026-11-09',
    type: 'review',
    category: 'microphones-and-recording',
    cover: true,
  },
  {
    title: 'Vari-Mu компрессия в вокальном тракте',
    content: 'Настраиваем медленную атаку и музыкальное высвобождение, чтобы сохранить динамику исполнения.',
    rating: 9.0,
    published_on: '2026-11-08',
    type: 'tutorial',
    category: 'sound-processing',
  },
  {
    title: 'Параметрический эквалайзер без лишней окраски',
    content: 'Практическая схема поиска резонансов и аккуратной коррекции перед ламповым каскадом.',
    rating: 8.5,
    published_on: '2026-11-07',
    type: 'tutorial',
    category: 'sound-processing',
  },
  {
    title: 'Мониторы SM-5 в малой студии',
    content: 'Проверяем размещение мониторов, точку прослушивания и влияние ближайших отражений.',
    rating: 8.7,
    published_on: '2026-11-06',
    type: 'review',
    category: 'studio-monitoring',
  },
  {
    title: 'Новая мастерская ручной сборки',
    content: 'Запущен участок финальной проверки: каждый прибор проходит измерения и прослушивание перед отправкой.',
    rating: 7.9,
    published_on: '2026-11-05',
    type: 'news',
    category: 'studio-monitoring',
  },
];

async function enablePublicRead(strapi) {
  const actions = [
    'api::article.article.find',
    'api::article.article.findOne',
    'api::category.category.find',
    'api::category.category.findOne',
  ];
  const publicRole = await strapi.db.query('plugin::users-permissions.role').findOne({
    where: { type: 'public' },
  });
  const permissions = await strapi.db.query('plugin::users-permissions.permission').findMany({
    where: { action: { $in: actions }, role: { id: publicRole.id } },
  });
  const enabledActions = new Set(permissions.map((permission) => permission.action));

  await Promise.all(
    actions
      .filter((action) => !enabledActions.has(action))
      .map((action) =>
        strapi.db.query('plugin::users-permissions.permission').create({
          data: { action, role: publicRole.id },
        })
      )
  );
}

async function uploadCover(strapi) {
  const existing = await strapi.db.query('plugin::upload.file').findOne({
    where: { name: 'tube-mic.jpg' },
  });
  if (existing) return existing;

  const filepath = path.join(__dirname, '..', 'database', 'seed', 'tube-mic.jpg');
  const [file] = await strapi.plugin('upload').service('upload').upload({
    data: {
      fileInfo: {
        name: 'tube-mic.jpg',
        alternativeText: 'Студийный микрофон на деревянной стойке',
        caption: 'Изображение переиспользовано из прошлой практики',
      },
    },
    files: {
      originalFilename: 'tube-mic.jpg',
      filepath,
      mimetype: 'image/jpeg',
      size: fs.statSync(filepath).size,
    },
  });
  return file;
}

async function seedDemoData(strapi) {
  const articleCount = await strapi.db.query('api::article.article').count();
  if (articleCount > 0) {
    strapi.log.info('Демонстрационные данные уже существуют, пропускаем заполнение.');
    return;
  }

  const cover = await uploadCover(strapi);
  const categoryDocuments = {};

  for (const category of categories) {
    const document = await strapi.documents('api::category.category').create({
      data: category,
      status: 'published',
    });
    categoryDocuments[category.slug] = document;
  }

  for (const article of articles) {
    const { category, cover: withCover, ...fields } = article;
    await strapi.documents('api::article.article').create({
      data: {
        ...fields,
        content: paragraph(fields.content),
        category: categoryDocuments[category].documentId,
        ...(withCover ? { cover: cover.id } : {}),
      },
      status: 'published',
    });
  }

  strapi.log.info(`Создано статей: ${articles.length}; рубрик: ${categories.length}; изображение загружено.`);
}

module.exports = {
  register() {},
  async bootstrap({ strapi }) {
    await enablePublicRead(strapi);
    if (process.env.SEED_DEMO_DATA === 'true') {
      await seedDemoData(strapi);
    }
  },
};
