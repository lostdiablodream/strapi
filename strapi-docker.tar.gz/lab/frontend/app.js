const API_URL = `${location.protocol}//${location.hostname}:1337`;
const typeNames = { news: 'Новость', tutorial: 'Руководство', review: 'Обзор' };

function blocksToText(blocks) {
  if (!Array.isArray(blocks)) return '';
  return blocks.flatMap((block) => block.children ?? []).map((child) => child.text ?? '').join(' ');
}

function createCard(article) {
  const card = document.createElement('article');
  card.className = 'card';

  if (article.cover?.url) {
    const image = document.createElement('img');
    image.src = `${API_URL}${article.cover.url}`;
    image.alt = article.cover.alternativeText || article.title;
    card.append(image);
  }

  const body = document.createElement('div');
  body.className = 'card-body';
  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = `${typeNames[article.type] ?? article.type ?? 'Материал'} · рейтинг ${article.rating ?? '—'} · ${article.published_on ?? 'без даты'}`;
  const title = document.createElement('h3');
  title.textContent = article.title;
  const text = document.createElement('p');
  text.textContent = blocksToText(article.content);
  body.append(meta, title, text);

  if (article.category?.name) {
    const category = document.createElement('span');
    category.className = 'category';
    category.textContent = article.category.name;
    body.append(category);
  }

  card.append(body);
  return card;
}

async function loadArticles() {
  const status = document.getElementById('status');
  try {
    const response = await fetch(`${API_URL}/api/articles?populate=*&sort=published_on:desc`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    const articles = payload.data ?? [];
    document.getElementById('list').replaceChildren(...articles.map(createCard));
    status.textContent = articles.length ? `Загружено статей: ${articles.length}` : 'Опубликованных статей пока нет.';
  } catch (error) {
    status.textContent = `Не удалось загрузить данные: ${error.message}`;
    status.classList.add('error');
  }
}

loadArticles();
